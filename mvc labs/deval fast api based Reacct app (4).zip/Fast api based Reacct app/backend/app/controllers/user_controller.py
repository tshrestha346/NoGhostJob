from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.schemas import Task as TaskSchema, User as UserSchema, UserCreate

router = APIRouter()


@router.get("/", response_model=list[UserSchema])
def list_users(db: Session = Depends(get_db)):
    return list(db.scalars(select(User)))


@router.get("/{user_id}/tasks", response_model=list[TaskSchema])
def list_user_tasks(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)

    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    return user.tasks
    
@router.post("/", response_model=UserSchema, status_code=201)
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    name = payload.name.strip()

    if not name:
        raise HTTPException(status_code=422, detail="Name cannot be empty")

    user = User(name=name)
    db.add(user)
    db.commit()
    db.refresh(user)

    return user