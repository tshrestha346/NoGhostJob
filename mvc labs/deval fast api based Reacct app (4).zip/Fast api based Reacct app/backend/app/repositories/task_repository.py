from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Task, User


class TaskRepository:
    def __init__(self, db: Session):
        self._db = db

    def all(self) -> list[Task]:
        return list(self._db.scalars(select(Task)))

    def find(self, task_id: int) -> Task | None:
        return self._db.get(Task, task_id)

    def find_user(self, user_id: int) -> User | None:
        return self._db.get(User, user_id)

    def add(self, title: str, owner_id: int) -> Task:
        task = Task(title=title, owner_id=owner_id)
        self._db.add(task)
        self._db.commit()
        self._db.refresh(task)
        return task

    def remove(self, task_id: int) -> bool:
        task = self.find(task_id)

        if task is None:
            return False

        self._db.delete(task)
        self._db.commit()
        return True