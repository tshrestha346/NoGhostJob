import React, { useEffect, useMemo, useState } from "react";
import {
  fetchUserTasks,
  fetchUsers,
  createUser,
  createTask,
  deleteTask,
} from "./services/api";
import "./App.css";

function AddUserForm({ onUserCreated }) {
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();

    if (!name.trim()) return;

    try {
      setSaving(true);
      const newUser = await createUser(name.trim());
      setName("");
      await onUserCreated(newUser);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="task-form">
      <input
        type="text"
        placeholder="Enter user name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <button type="submit" disabled={saving}>
        {saving ? "Adding..." : "Add User"}
      </button>
    </form>
  );
}

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [users, setUsers] = useState([]);
  const [title, setTitle] = useState("");
  const [selectedOwnerId, setSelectedOwnerId] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadTasksByUser(ownerId) {
    if (!ownerId) return;

    const tasksData = await fetchUserTasks(ownerId);
    setTasks(tasksData);
  }

  useEffect(() => {
    async function init() {
      try {
        setError("");

        const usersData = await fetchUsers();
        setUsers(usersData);

        if (usersData.length > 0) {
          const firstUserId = String(usersData[0].id);
          setSelectedOwnerId(firstUserId);

          const tasksData = await fetchUserTasks(firstUserId);
          setTasks(tasksData);
        }
      } catch (err) {
        console.error(err);
        setError("Could not load data. Check if backend is running.");
      } finally {
        setLoading(false);
      }
    }

    init();
  }, []);

  useEffect(() => {
    if (!selectedOwnerId) return;

    loadTasksByUser(selectedOwnerId).catch((err) => {
      console.error(err);
      setError("Could not load user tasks.");
    });
  }, [selectedOwnerId]);

  const usersById = useMemo(() => {
    return Object.fromEntries(users.map((user) => [user.id, user]));
  }, [users]);

  async function handleUserCreated(newUser) {
    setUsers((prev) => [...prev, newUser]);
    setSelectedOwnerId(String(newUser.id));
    setTasks([]);
  }

  async function handleAdd(e) {
    e.preventDefault();

    if (!title.trim() || !selectedOwnerId) return;

    try {
      setError("");

      await createTask(title.trim(), Number(selectedOwnerId));

      setTitle("");
      await loadTasksByUser(selectedOwnerId);
    } catch (err) {
      console.error(err);
      setError("Could not create task.");
    }
  }

  async function handleDelete(id) {
    try {
      setError("");
      await deleteTask(id);
      await loadTasksByUser(selectedOwnerId);
    } catch (err) {
      console.error(err);
      setError("Could not delete task.");
    }
  }

  if (loading) {
    return <p className="loading">Loading tasks...</p>;
  }

  return (
    <div className="page">
      <div className="todo-card">
        <h1>Todo List</h1>
        <p className="subtitle">Manage tasks user-wise</p>

        <AddUserForm onUserCreated={handleUserCreated} />

        <form onSubmit={handleAdd} className="task-form">
          <input
            type="text"
            placeholder="Enter task title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <select
            value={selectedOwnerId}
            onChange={(e) => setSelectedOwnerId(e.target.value)}
          >
            {users.map((user) => (
              <option key={user.id} value={user.id}>
                {user.name}
              </option>
            ))}
          </select>

          <button type="submit">Add Task</button>
        </form>

        {error && <p className="error">{error}</p>}

        <div className="task-list">
          {tasks.length === 0 ? (
            <p className="empty">No tasks for this user.</p>
          ) : (
            tasks.map((task) => (
              <div className="task-item" key={task.id}>
                <span>
                  {task.title}{" "}
                  <small>
                    — {usersById[task.owner_id]?.name || "Unknown user"}
                  </small>
                </span>

                <button onClick={() => handleDelete(task.id)}>Delete</button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}