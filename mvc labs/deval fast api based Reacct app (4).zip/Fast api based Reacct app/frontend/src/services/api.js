const API_URL = "http://localhost:8000";

async function request(path, options = {}) {
  const res = await fetch(`${API_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  if (!res.ok) {
    throw new Error(`Request failed: ${res.status}`);
  }

  if (res.status === 204) return null;

  return res.json();
}

export function fetchTasks() {
  return request("/tasks/");
}

export function fetchUserTasks(userId) {
  return request(`/users/${userId}/tasks`);
}

export function fetchUsers() {
  return request("/users/");
}

export function createUser(name) {
  return request("/users/", {
    method: "POST",
    body: JSON.stringify({ name }),
  });
}

export function createTask(title, owner_id) {
  return request("/tasks/", {
    method: "POST",
    body: JSON.stringify({ title, owner_id }),
  });
}

export function deleteTask(id) {
  return request(`/tasks/${id}`, {
    method: "DELETE",
  });
}