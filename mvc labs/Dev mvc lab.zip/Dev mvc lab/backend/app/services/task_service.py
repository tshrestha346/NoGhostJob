from app.repositories.task_repository import TaskRepository


class TaskNotFoundError(Exception):
    ...


class TaskService:
    def __init__(self, repo: TaskRepository):
        self._repo = repo

    def list_tasks(self):
        return self._repo.all()

    def get_task(self, task_id: int):
        task = self._repo.find(task_id)

        if task is None:
            raise TaskNotFoundError()

        return task

    def create_task(self, title: str):
        title = title.strip()

        if not title:
            raise ValueError("Title cannot be empty")

        return self._repo.add(title)

    def delete_task(self, task_id: int) -> bool:
        return self._repo.remove(task_id)